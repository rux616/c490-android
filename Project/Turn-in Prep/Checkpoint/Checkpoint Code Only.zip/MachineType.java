/*--------------------------------------------------------------------------------------------------
 * Author:      Dan Cassidy
 * Date:        2015-08-04
 * Assignment:  Project
 * Source File: MachineType.java
 * Language:    Java
 * Course:      CSCI-C 490, Android Programming, MoWe 08:00
--------------------------------------------------------------------------------------------------*/
package com.chaoticcognitions.aenigma.models.machines;

import com.chaoticcognitions.aenigma.models.rotors.RotorType;

/**
 * Enum to store the relevant information about the different types of Enigma machines in a single
 * place.
 * @author Dan Cassidy
 */
public enum MachineType {
    ENIGMA_I,
    NORWAY_ENIGMA,
    ENIGMA_M3,
    ENIGMA_M4,
    ENIGMA_G,
    ENIGMA_D,
    ENIGMA_K,
    SWISS_K,
    ENIGMA_KD,
    RAILWAY_ENIGMA,
    ENIGMA_T;

    /**
     * Gets a list of possible stators for the given machine type.
     * @return The possible stators for the given machine type.
     */
    public RotorType[] possibleStators() {
        switch (this) {
            case ENIGMA_I:
                return new RotorType[]{RotorType.I_ETW};
            case NORWAY_ENIGMA:
                return new RotorType[]{RotorType.N_ETW};
            case ENIGMA_M3:
                return new RotorType[]{RotorType.M3_ETW};
            case ENIGMA_M4:
                return new RotorType[]{RotorType.M4_ETW};
            case ENIGMA_G:
                return new RotorType[]{RotorType.G_ETW};
            case ENIGMA_D:
                return new RotorType[]{RotorType.D_ETW};
            case ENIGMA_K:
                return new RotorType[]{RotorType.K_ETW};
            case SWISS_K:
                return new RotorType[]{RotorType.KS_ETW};
            case ENIGMA_KD:
                return new RotorType[]{RotorType.KD_ETW};
            case RAILWAY_ENIGMA:
                return new RotorType[]{RotorType.R_ETW};
            case ENIGMA_T:
                return new RotorType[]{RotorType.T_ETW};
                
            default:
                return new RotorType[]{};
        }
    }

    /**
     * Gets a list of possible rotors for the given machine type.
     * @return The possible rotors for the given machine type.
     */
    public RotorType[] possibleRotors() {
        switch (this) {
            case ENIGMA_I:
                return new RotorType[]{RotorType.I_I, RotorType.I_II, RotorType.I_III, RotorType.I_IV, RotorType.I_V};
            case NORWAY_ENIGMA:
                return new RotorType[]{RotorType.N_I, RotorType.N_II, RotorType.N_III, RotorType.N_IV, RotorType.N_V};
            case ENIGMA_M3:
                return new RotorType[]{RotorType.M3_I, RotorType.M3_II, RotorType.M3_III, RotorType.M3_IV, RotorType.M3_V, RotorType.M3_VI, RotorType.M3_VII, RotorType.M3_VIII};
            case ENIGMA_M4:
                return new RotorType[]{RotorType.M4_I, RotorType.M4_II, RotorType.M4_III, RotorType.M4_IV, RotorType.M4_V, RotorType.M4_VI, RotorType.M4_VII, RotorType.M4_VIII, RotorType.M4_BETA, RotorType.M4_GAMMA};
            case ENIGMA_G:
                return new RotorType[]{RotorType.G_I, RotorType.G_II, RotorType.G_III};
            case ENIGMA_D:
                return new RotorType[]{RotorType.D_I, RotorType.D_II, RotorType.D_III};
            case ENIGMA_K:
                return new RotorType[]{RotorType.K_I, RotorType.K_II, RotorType.K_III};
            case SWISS_K:
                return new RotorType[]{RotorType.KS_I, RotorType.KS_II, RotorType.KS_III};
            case ENIGMA_KD:
                return new RotorType[]{RotorType.KD_I, RotorType.KD_II, RotorType.KD_III};
            case RAILWAY_ENIGMA:
                return new RotorType[]{RotorType.R_I, RotorType.R_II, RotorType.R_III};
            case ENIGMA_T:
                return new RotorType[]{RotorType.T_I, RotorType.T_II, RotorType.T_III, RotorType.T_IV, RotorType.T_V, RotorType.T_VI, RotorType.T_VII, RotorType.T_VIII};

            default:
                return new RotorType[]{};
        }
    }

    /**
     * Gets a list of possible reflectors for the given machine type.
     * @return The possible reflectors for the given machine type.
     */
    public RotorType[] possibleReflectors(){
        switch (this) {
            case ENIGMA_I:
                return new RotorType[]{RotorType.I_UKW_A, RotorType.I_UKW_B, RotorType.I_UKW_C};
            case NORWAY_ENIGMA:
                return new RotorType[]{RotorType.N_UKW};
            case ENIGMA_M3:
                return new RotorType[]{RotorType.M3_UKW_B, RotorType.M3_UKW_C};
            case ENIGMA_M4:
                return new RotorType[]{RotorType.M4_UKW_B, RotorType.M4_UKW_C};
            case ENIGMA_G:
                return new RotorType[]{RotorType.G_UKW};
            case ENIGMA_D:
                return new RotorType[]{RotorType.D_UKW};
            case ENIGMA_K:
                return new RotorType[]{RotorType.K_UKW};
            case SWISS_K:
                return new RotorType[]{RotorType.KS_UKW};
            case ENIGMA_KD:
                return new RotorType[]{RotorType.KD_UKW};
            case RAILWAY_ENIGMA:
                return new RotorType[]{RotorType.R_UKW};
            case ENIGMA_T:
                return new RotorType[]{RotorType.T_UKW};

            default:
                return new RotorType[]{};
        }
    }

    /**
     * Gets whether the machine is Enigma stepped or not based on the type.
     * @return The possible stators for the given machine type.
     */
    public boolean isEnigmaStepped() {
        switch (this) {
            case ENIGMA_I:
            case NORWAY_ENIGMA:
            case ENIGMA_M3:
            case ENIGMA_M4:
            case ENIGMA_D:
            case ENIGMA_K:
            case SWISS_K:
            case ENIGMA_KD:
            case RAILWAY_ENIGMA:
            case ENIGMA_T:
                return true;
            case ENIGMA_G:
                return false;

            default:
                return true;
        }
    }

    /**
     * Gets whether the machine's reflector is visible or not based on the type.
     * @return Whether the machine's reflector is visible.
     */
    public boolean hasVisibleReflector() {
        switch (this) {
            case ENIGMA_I:
            case NORWAY_ENIGMA:
            case ENIGMA_M3:
            case ENIGMA_M4:
                return false;
            case ENIGMA_G:
            case ENIGMA_D:
            case ENIGMA_K:
            case SWISS_K:
            case ENIGMA_KD:
            case RAILWAY_ENIGMA:
            case ENIGMA_T:
                return true;

            default:
                return false;
        }
    }

    //TODO create method comment
    public boolean hasPlugboard() {
        switch (this) {
            case ENIGMA_I:
            case NORWAY_ENIGMA:
            case ENIGMA_M3:
            case ENIGMA_M4:
                return true;
            case ENIGMA_G:
            case ENIGMA_D:
            case ENIGMA_K:
            case SWISS_K:
            case ENIGMA_KD:
            case RAILWAY_ENIGMA:
            case ENIGMA_T:
                return false;

            default:
                return false;
        }
    }

    /**
     * Gets the number of rotors a machine has based on its type. Note that this is only describing
     * the number of actual rotors and does not include the stator or reflector.
     * @return The number of rotors the machine has.
     */
    public int numberOfRotors() {
        switch (this) {
            case ENIGMA_I:
            case NORWAY_ENIGMA:
            case ENIGMA_M3:
            case ENIGMA_G:
            case ENIGMA_D:
            case ENIGMA_K:
            case SWISS_K:
            case ENIGMA_KD:
            case RAILWAY_ENIGMA:
            case ENIGMA_T:
                return 3;
            case ENIGMA_M4:
                return 4;

            default:
                return 3;
        }
    }

    /**
     * Returns the string representation of the machine type.
     * @return The string representation of the machine type.
     */
    @Override public String toString() {
        switch (this) {
            case ENIGMA_I:
                return "Enigma I";
            case NORWAY_ENIGMA:
                return "Norway Enigma";
            case ENIGMA_M3:
                return "Enigma M3";
            case ENIGMA_M4:
                return "Enigma M4";
            case ENIGMA_G:
                return "Enigma G";
            case ENIGMA_D:
                return "Enigma D";
            case ENIGMA_K:
                return "Enigma K";
            case SWISS_K:
                return "Swiss-K";
            case ENIGMA_KD:
                return "Enigma KD";
            case RAILWAY_ENIGMA:
                return "Railway Enigma";
            case ENIGMA_T:
                return "Enigma T";

            default:
                return "Unknown";
        }
    }
}
