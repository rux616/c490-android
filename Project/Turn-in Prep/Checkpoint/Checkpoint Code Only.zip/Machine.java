//TODO create file comment
package com.chaoticcognitions.aenigma.models.machines;

import com.chaoticcognitions.aenigma.models.plugboards.Plugboard;
import com.chaoticcognitions.aenigma.models.rotors.Rotor;
import com.chaoticcognitions.aenigma.models.rotors.RotorType;

import static com.chaoticcognitions.aenigma.models.rotors.Rotor.Direction;

/**
 * TODO finish class comment
 * @author Dan Cassidy
 */
public class Machine {
    public enum RotorPosition {RIGHT, MIDDLE, LEFT, GREEK, REFLECTOR}

    //TODO comment field groupings
    private final MachineType machineType;
    private final boolean isEnigmaStepped;
    private final int numberOfRotors;
    private final boolean hasVisibleReflector;
    private final boolean hasPlugboard;

    private final RotorType[] possibleStators;
    private final RotorType[] possibleRotors;
    private final RotorType[] possibleReflectors;

    private Plugboard plugboard;

    private Rotor stator;
    private Rotor[] rotors;
    private Rotor reflector;

    //TODO create method comment
    public Machine(MachineType machineType) {
        this.machineType = machineType;

        isEnigmaStepped = this.machineType.isEnigmaStepped();
        numberOfRotors = this.machineType.numberOfRotors();
        hasVisibleReflector = this.machineType.hasVisibleReflector();
        hasPlugboard = this.machineType.hasPlugboard();
        possibleStators = this.machineType.possibleStators();
        possibleRotors = this.machineType.possibleRotors();
        possibleReflectors = this.machineType.possibleReflectors();

        plugboard = new Plugboard();

        rotors = new Rotor[numberOfRotors];
    }

    // BEGIN GETTERS AND SETTERS -->
    public MachineType getMachineType() {
        return machineType;
    }

    public void setStator(RotorType statorType) {
        if (!isValidStator(statorType))
            throw new IllegalArgumentException("Invalid stator type.");
        this.stator = new Rotor(statorType);
    }

    public void setReflector(RotorType reflectorType) {
        if (!isValidReflector(reflectorType))
            throw new IllegalArgumentException("Invalid reflector type.");
        reflector = new Rotor(reflectorType);
    }

    public void setRotor(RotorType rotorType, RotorPosition position) {
        if (!isValidRotor(rotorType) || !isValidPosition(position))
            throw new IllegalArgumentException("Invalid rotor type or position.");
        rotors[position.ordinal()] = new Rotor(rotorType);
    }

    public void setPlugboardPairs(String plugPairs) {
        for (int index = 0; index < plugPairs.length() && index + 1 < plugPairs.length(); index += 2)
            plugboard.addPlugSettings(plugPairs.charAt(index), plugPairs.charAt(index + 1));
    }

    public void setRingSetting(char ringSetting, RotorPosition position) {
        if (!isValidPosition(position))
            throw new IllegalArgumentException("Invalid position.");
        if (position == RotorPosition.REFLECTOR)
            reflector.setRingSetting(ringSetting);
        else
            rotors[position.ordinal()].setRingSetting(ringSetting);
    }

    public void setVisiblePosition(char visiblePosition, RotorPosition position) {
        if (!isValidPosition(position))
            throw new IllegalArgumentException("Invalid position.");
        if (position == RotorPosition.REFLECTOR)
            reflector.setVisiblePosition(visiblePosition);
        else
            rotors[position.ordinal()].setVisiblePosition(visiblePosition);
    }
    // <-- END GETTERS AND SETTERS

    //TODO create method comment
    public char encode(char inputChar) {
        // step
        doStep();
        // encode plugboard
        if (hasPlugboard)
            inputChar = plugboard.encode(inputChar);
        // encode stator
        inputChar = stator.encode(inputChar, Direction.RIGHT_TO_LEFT);
        // encode rotor array
        for (Rotor rotor : rotors)
            inputChar = rotor.encode(inputChar, Direction.RIGHT_TO_LEFT);
        // encode reflector
        inputChar = reflector.encode(inputChar, Direction.RIGHT_TO_LEFT);
        // encode rotor array (reverse)
        for (int index = numberOfRotors - 1; index >= 0; index--)
            inputChar = rotors[index].encode(inputChar, Direction.LEFT_TO_RIGHT);
        // encode stator (reverse)
        inputChar = stator.encode(inputChar, Direction.LEFT_TO_RIGHT);
        // encode plugboard (reverse)
        if (hasPlugboard)
            inputChar = plugboard.encode(inputChar);
        return inputChar;
    }

    //TODO create method comment
    public String encode(String inputString) {
        String toReturn = "";
        for (char inputChar : inputString.toCharArray())
            toReturn += encode(inputChar);
        return toReturn;
    }

    //TODO create method comment
    private void doStep() {
        //TODO see if this method can be optimized at all
        if (isEnigmaStepped) {
            if (rotors[RotorPosition.RIGHT.ordinal()].isAtTurnoverPosition()) {
                // normal stepping
                if (rotors[RotorPosition.MIDDLE.ordinal()].isAtTurnoverPosition()) {
                    if (rotors[RotorPosition.LEFT.ordinal()].isAtTurnoverPosition()) {
                        reflector.doStep();
                    }
                    rotors[RotorPosition.LEFT.ordinal()].doStep();
                }
                rotors[RotorPosition.MIDDLE.ordinal()].doStep();
            } else {
                // double stepping (?)
                if (rotors[RotorPosition.MIDDLE.ordinal()].isAtTurnoverPosition() &&
                        rotors[RotorPosition.MIDDLE.ordinal()].justStepped()) {
                    rotors[RotorPosition.LEFT.ordinal()].doStep();
                    rotors[RotorPosition.MIDDLE.ordinal()].doStep();
                }
            }
            rotors[RotorPosition.RIGHT.ordinal()].doStep();
        } else {
            if (rotors[RotorPosition.RIGHT.ordinal()].isAtTurnoverPosition()) {
                if (rotors[RotorPosition.MIDDLE.ordinal()].isAtTurnoverPosition()) {
                    if (rotors[RotorPosition.LEFT.ordinal()].isAtTurnoverPosition()) {
                        reflector.doStep();
                    }
                    rotors[RotorPosition.LEFT.ordinal()].doStep();
                }
                rotors[RotorPosition.MIDDLE.ordinal()].doStep();
            }
            rotors[RotorPosition.RIGHT.ordinal()].doStep();
        }
    }

    //TODO create method comment
    @Override public String toString() {
        String toReturn = "";
        for (Rotor rotor : rotors)
            toReturn = rotor.getVisiblePosition() + (toReturn.isEmpty() ? "" : " ") + toReturn;
        if (hasVisibleReflector)
            toReturn = reflector.getVisiblePosition() + " " + toReturn;
        return toReturn;
    }

    //TODO create method comment
    private boolean isValidStator(RotorType statorToValidate) {
        for (RotorType stator : possibleStators)
            if (statorToValidate == stator)
                return true;

        return false;
    }

    //TODO create method comment
    private boolean isValidRotor(RotorType rotorToValidate) {
        for (RotorType rotor : possibleRotors)
            if (rotorToValidate == rotor)
                return true;

        return false;
    }

    //TODO create method comment
    private boolean isValidReflector(RotorType reflectorToValidate) {
        for (RotorType reflector : possibleReflectors)
            if (reflectorToValidate == reflector)
                return true;

        return false;
    }

    //TODO create method comment
    private boolean isValidPosition(RotorPosition positionToValidate) {
        return !(positionToValidate == RotorPosition.GREEK && numberOfRotors != 4);
    }

    //TODO create method comment
    private boolean isReady() {
        for (Rotor rotor : rotors)
            if (rotor == null)
                return false;
        return (stator != null && reflector != null && plugboard != null);
    }
}
