package com.chaoticcognitions.aenigma.models.rotors;

import android.util.Log;

/**
 * Class to handle the functionality of the Enigma machine rotors.
 * @author Dan Cassidy
 */
public class Rotor {
    public enum Direction {RIGHT_TO_LEFT, LEFT_TO_RIGHT}

    private static final char CHAR_OFFSET = 'A';
    private final int CHAR_SET_SIZE;

    // Once set, these fields will not be changed. Comprise basic rotor settings. They are stored
    // inside the Rotor class itself to avoid having an excessive amount of calls to the various
    // methods of the RotorType enum.
    private final RotorType rotorType;
    private final String wiring;
    private final String reverseWiring;
    private final String turnoverChars;
    private final boolean isSteppingRotor;
    private final boolean isMarkedWithNumbers;

    // User-changeable fields.
    private char visiblePosition = 'A'; //TODO can change name to something more representative?
    private char ringSetting = 'A';

    // Automatic field to deal with turnover and stepping.
    private boolean isAtTurnoverPosition = false;
    private boolean justStepped = false; //TODO needed?
    private boolean steppingBuffer = false; //TODO needed?

    /**
     * 1-parameter constructor.
     * @param rotorType The type of rotor to construct.
     */
    public Rotor(RotorType rotorType) {
        this.rotorType = rotorType;

        wiring = this.rotorType.wiring();
        reverseWiring = this.rotorType.reverseWiring();
        turnoverChars = this.rotorType.turnoverChars();
        isSteppingRotor = this.rotorType.isSteppingRotor();
        isMarkedWithNumbers = this.rotorType.isMarkedWithNumbers();

        CHAR_SET_SIZE = wiring.length();

        checkTurnover();
    }

    // BEGIN GETTERS AND SETTERS -->
    public RotorType getRotorType() {
        return rotorType;
    }

    public String getVisiblePosition() {
        if (isMarkedWithNumbers) {
            int visibleNumber = visiblePosition - 'A' + 1;
            return (visibleNumber < 10 ? "0" + visibleNumber : "" + visibleNumber);
        } else
            return Character.toString(visiblePosition);
    }

    public void setVisiblePosition(char visiblePosition) throws IllegalArgumentException {
        if (!isValidChar(visiblePosition))
            throw new IllegalArgumentException("Invalid position setting.");

        this.visiblePosition = visiblePosition;
        checkTurnover();
    }

    public char getRingSetting() {
        return ringSetting;
    }

    public void setRingSetting(char ringSetting) throws IllegalArgumentException {
        if (!isValidChar(ringSetting))
            throw new IllegalArgumentException("Invalid ring setting.");
        this.ringSetting = ringSetting;
    }

    public boolean justStepped() {
        return justStepped;
    }

    public boolean isAtTurnoverPosition() {
        return isAtTurnoverPosition;
    }
    // <-- END GETTERS AND SETTERS

    /**
     * Encodes a character where the input is on the main (right) side of the rotor.
     * @param inputChar The character to encode.
     * @return The encoded character.
     */
    public char encode(char inputChar, Direction direction) throws IllegalArgumentException {
        if (!isValidChar(inputChar))
            throw new IllegalArgumentException("Invalid");

        // Helper code for stepping. //TODO determine if actually needed
        if (steppingBuffer)
            steppingBuffer = false;
        else
            justStepped = false;

        // Determine the current offset.
        int offset = ringSetting - visiblePosition;
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] current offset: " + offset + ".");

        // Remove the offset to get the true input character.
        inputChar -= offset;
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] true input character (pre-normalization): " + inputChar + ".");

        // Normalize the true input character to handle any rollover. (E.g. - A character beyond 'Z'
        // will get rolled over from the end of the rotor back to the beginning.)
        inputChar = normalize(inputChar);
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] true input character (post-normalization): " + inputChar + ".");

        // Get the corresponding character that the true input character is wired to on the rotor.
        char outputChar;
        if (direction == Direction.RIGHT_TO_LEFT)
            outputChar = wiring.charAt(inputChar - CHAR_OFFSET);
        else
            outputChar = reverseWiring.charAt(inputChar - CHAR_OFFSET);
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] true output character: " + outputChar + ".");

        // Add the offset back to the character.
        outputChar += offset;
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] final output character (pre-normalization): " + outputChar + ".");

        // Normalize the offset output character to handle any rollover and get the final output
        // character.
        outputChar = normalize(outputChar);
        Log.i("Rotor", "Rotor " + rotorType + " [encode(" + direction.toString().charAt(0) + ")] final output character (post-normalization): " + outputChar + ".");

        // Return the final output character.
        return outputChar;
    }

    /**
     * Steps the rotor.
     */
    public void doStep() {
        // If this rotor does not step, just return, otherwise proceed with stepping.
        if (!isSteppingRotor)
            return;

        // TODO: Verify rotor stepping method. <-- Tentatively good.
        Log.i("Rotor", "Rotor " + rotorType + " stepping from '" + visiblePosition + "' to '" +
                (visiblePosition == 'Z' ? 'A' : (char)(visiblePosition + 1)) + "'.");

        // Step the rotor and normalize (handle rollover) if needed.
        visiblePosition = normalize(++visiblePosition);

        // Set some flags to advertise the fact this rotor just stepped. TODO needed?
        justStepped = true;
        steppingBuffer = true;

        // Check to see if this rotor is at a turnover position.
        checkTurnover();
    }

    /**
     * Determines whether the rotor is at a turnover position or not.
     */
    private void checkTurnover() {
        isAtTurnoverPosition = (turnoverChars.indexOf(visiblePosition) != -1);
    }

    /**
     * Determines whether the argument is a valid character.
     * @param charToValidate The character to validate.
     * @return boolean, representing whether the argument is a valid character (true) or not (false).
     */
    private boolean isValidChar(char charToValidate) {
        return (wiring.indexOf(charToValidate) != -1);
    }

    /**
     * Normalize the given character to within the rotor's character set. In other words, handle
     * the rollover from the end of the character set to the beginning, or from the beginning of the
     * character set to the end.
     * @param charToNormalize The character to normalize.
     * @return char, containing the normalized character.
     */
    private char normalize(char charToNormalize) {
        if (charToNormalize < CHAR_OFFSET)
            charToNormalize += CHAR_SET_SIZE;
        else if (charToNormalize >= CHAR_OFFSET + CHAR_SET_SIZE)
            charToNormalize -= CHAR_SET_SIZE;
        return charToNormalize;
    }
}
